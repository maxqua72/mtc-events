import { c as defineEventHandler, m as getRequestIP, f as createError, u as useRuntimeConfig, i as getHeader, n as runTask } from '../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const rolling_get = defineEventHandler(async (event) => {
  const clientAddress = getRequestIP(event, { xForwardedFor: true });
  const isLocal = clientAddress === "127.0.0.1" || clientAddress === "::1";
  if (!isLocal) {
    throw createError({ statusCode: 403, message: "Accesso consentito solo localmente" });
  }
  useRuntimeConfig();
  const authHeader = getHeader(event, "Authorization");
  if (authHeader !== `Bearer ${process.env.CRON_SECRET}`) {
    throw createError({ statusCode: 401, message: "Non autorizzato" });
  }
  const result = await runTask("events:rolling");
  return {
    success: true,
    timestamp: (/* @__PURE__ */ new Date()).toISOString(),
    result
  };
});

export { rolling_get as default };
//# sourceMappingURL=rolling.get.mjs.map
