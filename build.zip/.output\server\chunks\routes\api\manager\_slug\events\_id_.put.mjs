import { c as defineEventHandler, g as getRouterParam, e as getDb, r as readBody, l as libExports } from '../../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const _id__put = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const db = await getDb();
  const body = await readBody(event);
  const { _id, asd_slug, ...updateData } = body;
  const oldEvent = await db.collection("events").findOne({ _id: new libExports.ObjectId(id) });
  if ((oldEvent == null ? void 0 : oldEvent.resource_id) && String(oldEvent.resource_id) !== String(updateData.resource_id)) {
    const oldFile = await db.collection("resources.files").findOne({
      _id: new libExports.ObjectId(oldEvent.resource_id),
      "metadata.is_event_private": true
    });
    if (oldFile) {
      const bucket = new libExports.GridFSBucket(db, { bucketName: "resources" });
      try {
        await bucket.delete(oldFile._id);
      } catch (err) {
        console.error("Errore eliminazione vecchio file orfano:", err);
      }
    }
  }
  if (updateData.association_id && typeof updateData.association_id === "string") {
    updateData.association_id = new libExports.ObjectId(updateData.association_id);
  }
  if (updateData.resource_id && typeof updateData.resource_id === "string") {
    updateData.resource_id = new libExports.ObjectId(updateData.resource_id);
  }
  if (updateData.start_date) updateData.start_date = new Date(updateData.start_date);
  if (updateData.end_date) updateData.end_date = new Date(updateData.end_date);
  if (updateData.registration_time) updateData.registration_time = new Date(updateData.registration_time);
  await db.collection("events").updateOne(
    { _id: new libExports.ObjectId(id) },
    {
      $set: {
        ...updateData,
        updated_at: /* @__PURE__ */ new Date()
      }
    }
  );
  return { success: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
