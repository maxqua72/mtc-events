import { c as defineEventHandler, g as getRouterParam, f as createError, e as getDb, w as readMultipartFormData, l as libExports } from '../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const index_post = defineEventHandler(async (event) => {
  var _a, _b;
  const slug = getRouterParam(event, "slug");
  if (!slug) {
    throw createError({ statusCode: 400, statusMessage: "Slug mancante" });
  }
  const db = await getDb();
  const asd = await db.collection("associations").findOne({ slug });
  if (!asd) {
    throw createError({ statusCode: 404, statusMessage: "ASD non trovata" });
  }
  const formData = await readMultipartFormData(event);
  if (!formData) {
    throw createError({ statusCode: 400, statusMessage: "Nessun dato ricevuto" });
  }
  const fileField = formData.find((f) => f.name === "file");
  const nameField = formData.find((f) => f.name === "name");
  if (!fileField || !fileField.data || !fileField.filename) {
    throw createError({ statusCode: 400, statusMessage: "File non valido" });
  }
  const privateField = formData.find((f) => f.name === "is_event_private");
  const isPrivate = ((_a = privateField == null ? void 0 : privateField.data) == null ? void 0 : _a.toString()) === "true";
  const bucket = new libExports.GridFSBucket(db, { bucketName: "resources" });
  const uploadStream = bucket.openUploadStream(fileField.filename, {
    metadata: {
      displayName: ((_b = nameField == null ? void 0 : nameField.data) == null ? void 0 : _b.toString()) || fileField.filename,
      association_id: asd._id,
      contentType: fileField.type || "application/octet-stream",
      // Salviamolo qui
      size: fileField.data.length,
      is_event_private: isPrivate
    }
  });
  return new Promise((resolve, reject) => {
    uploadStream.on("finish", () => {
      var _a2;
      resolve({
        _id: uploadStream.id,
        // Questo sarà l'URL che useremo per visualizzare l'immagine
        url: `/api/assets/${uploadStream.id}`,
        name: ((_a2 = nameField == null ? void 0 : nameField.data) == null ? void 0 : _a2.toString()) || fileField.filename
      });
    });
    uploadStream.on("error", (err) => {
      reject(createError({ statusCode: 500, statusMessage: "Errore durante il salvataggio nel DB" }));
    });
    uploadStream.end(fileField.data);
  });
});

export { index_post as default };
//# sourceMappingURL=index.post4.mjs.map
