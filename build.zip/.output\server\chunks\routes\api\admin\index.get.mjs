import { c as defineEventHandler, e as getDb } from '../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const db = await getDb();
  const associations = await db.collection("associations").aggregate([
    {
      $lookup: {
        from: "managers",
        localField: "_id",
        foreignField: "association_id",
        as: "manager_links"
      }
    },
    {
      $lookup: {
        from: "users",
        localField: "manager_links.user_id",
        foreignField: "_id",
        as: "manager_details"
      }
    },
    {
      $project: {
        name: 1,
        slug: 1,
        theme_color: 1,
        logo_url: 1,
        created_at: 1,
        // Mappiamo i dettagli degli utenti trovati
        managers: {
          $map: {
            input: "$manager_details",
            as: "m",
            in: { name: "$$m.name", email: "$$m.email" }
          }
        }
      }
    },
    { $sort: { name: 1 } }
  ]).toArray();
  return associations;
});

export { index_get as default };
//# sourceMappingURL=index.get.mjs.map
