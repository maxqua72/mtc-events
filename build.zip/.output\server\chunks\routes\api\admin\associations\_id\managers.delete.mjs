import { c as defineEventHandler, g as getRouterParam, h as getQuery, e as getDb, l as libExports, f as createError } from '../../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const managers_delete = defineEventHandler(async (event) => {
  const asdId = getRouterParam(event, "id");
  const query = getQuery(event);
  const userEmail = query.email;
  const db = await getDb();
  if (!asdId || !libExports.ObjectId.isValid(asdId)) {
    throw createError({ statusCode: 400, statusMessage: "ID ASD non valido" });
  }
  if (!userEmail) {
    throw createError({ statusCode: 400, statusMessage: "Email manager necessaria per la rimozione" });
  }
  const user = await db.collection("users").findOne({ email: userEmail.toLowerCase() });
  if (!user) {
    throw createError({ statusCode: 404, statusMessage: "Utente non trovato" });
  }
  const result = await db.collection("managers").deleteOne({
    user_id: new libExports.ObjectId(user._id),
    association_id: new libExports.ObjectId(asdId)
  });
  if (result.deletedCount === 0) {
    throw createError({
      statusCode: 404,
      statusMessage: "L'utente non risulta essere un manager per questa associazione"
    });
  }
  return { success: true, message: "Ruolo manager revocato con successo" };
});

export { managers_delete as default };
//# sourceMappingURL=managers.delete.mjs.map
