import { c as defineEventHandler, e as getDb, r as readBody, f as createError } from '../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const index_post = defineEventHandler(async (event) => {
  const db = await getDb();
  const body = await readBody(event);
  if (!body.name || !body.slug) {
    throw createError({ statusCode: 400, statusMessage: "Nome e Slug sono obbligatori" });
  }
  const cleanSlug = body.slug.toLowerCase().trim().replace(/\s+/g, "-");
  const existing = await db.collection("associations").findOne({ slug: cleanSlug });
  if (existing) {
    throw createError({ statusCode: 409, statusMessage: "Questo slug \xE8 gi\xE0 utilizzato" });
  }
  const newAsd = {
    name: body.name,
    slug: cleanSlug,
    theme_color: body.theme_color || "#3b82f6",
    logo_url: body.logo_url || null,
    // L'URL dell'immagine caricata in GridFS
    created_at: /* @__PURE__ */ new Date(),
    updated_at: /* @__PURE__ */ new Date()
  };
  const result = await db.collection("associations").insertOne(newAsd);
  return {
    ...newAsd,
    _id: result.insertedId
  };
});

export { index_post as default };
//# sourceMappingURL=index.post.mjs.map
