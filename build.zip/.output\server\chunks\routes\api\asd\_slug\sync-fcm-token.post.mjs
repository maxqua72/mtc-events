import { c as defineEventHandler, g as getRouterParam, e as getDb, r as readBody, f as createError } from '../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const syncFcmToken_post = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  const db = await getDb();
  const body = await readBody(event);
  const { email, token } = body;
  if (!email || !token) {
    throw createError({
      statusCode: 400,
      statusMessage: "Email e Token sono obbligatori"
    });
  }
  const association = await db.collection("associations").findOne({ slug });
  if (!association) {
    throw createError({
      statusCode: 404,
      statusMessage: "Associazione non trovata"
    });
  }
  const normalizedEmail = email.toLowerCase();
  const memberResult = await db.collection("memberships").updateOne(
    {
      email: normalizedEmail,
      association_id: association._id
    },
    {
      $addToSet: { fcm_tokens: token },
      $set: { updated_at: /* @__PURE__ */ new Date() }
    }
  );
  if (memberResult.matchedCount === 0) {
    await db.collection("users").updateOne(
      { email: normalizedEmail },
      {
        $addToSet: { fcm_tokens: token },
        $set: { updated_at: /* @__PURE__ */ new Date() }
      }
    );
    return {
      success: true,
      target: "manager",
      message: "Token sincronizzato nel profilo utente/manager"
    };
  }
  return {
    success: true,
    target: "member",
    message: "Token sincronizzato nella membership del socio"
  };
});

export { syncFcmToken_post as default };
//# sourceMappingURL=sync-fcm-token.post.mjs.map
