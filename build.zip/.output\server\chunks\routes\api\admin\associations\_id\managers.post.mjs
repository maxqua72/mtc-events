import { c as defineEventHandler, g as getRouterParam, e as getDb, r as readBody, f as createError, l as libExports } from '../../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const managers_post = defineEventHandler(async (event) => {
  var _a;
  const asdId = getRouterParam(event, "id");
  const db = await getDb();
  const body = await readBody(event);
  const email = (_a = body.email) == null ? void 0 : _a.toLowerCase().trim();
  if (!asdId || asdId === "undefined") {
    throw createError({ statusCode: 400, statusMessage: "ID ASD mancante o non valido" });
  }
  let user = await db.collection("users").findOne({ email });
  if (!user) {
    const result = await db.collection("users").insertOne({
      email,
      name: body.name || "Nuovo Utente",
      // Fallback se il nome mancasse
      created_at: /* @__PURE__ */ new Date(),
      is_admin: false
      // Default per i nuovi MANAGER
    });
    user = { _id: result.insertedId };
  }
  await db.collection("managers").updateOne(
    {
      user_id: new libExports.ObjectId(user._id),
      association_id: new libExports.ObjectId(asdId)
    },
    {
      $set: {
        role: "MANAGER",
        assigned_at: /* @__PURE__ */ new Date()
      }
    },
    { upsert: true }
  );
  return { success: true };
});

export { managers_post as default };
//# sourceMappingURL=managers.post.mjs.map
