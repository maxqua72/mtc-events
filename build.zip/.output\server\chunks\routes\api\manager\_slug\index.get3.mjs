import { c as defineEventHandler, g as getRouterParam, e as getDb } from '../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  const db = await getDb();
  const asd = await db.collection("associations").findOne({ slug });
  if (!asd) return [];
  const [members, pendingEmails] = await Promise.all([
    db.collection("memberships").find({ association_id: asd._id }).sort({ expiry_date: 1 }).toArray(),
    // <--- Cast del tipo qui
    db.collection("email_queue").find({ asd_slug: slug, status: "pending" }).project({ recipient: 1, scheduled_at: 1 }).toArray()
    // <--- Cast del tipo qui
  ]);
  const pendingMap = new Map(
    pendingEmails.map((e) => [
      e.recipient.trim().toLowerCase(),
      e.scheduled_at
    ])
  );
  const enrichedMembers = members.map((m) => {
    const normalizedEmail = (m.email || "").trim().toLowerCase();
    const isPending = pendingMap.has(normalizedEmail);
    return {
      ...m,
      is_email_pending: isPending,
      scheduled_at: isPending ? pendingMap.get(normalizedEmail) : null
    };
  });
  return enrichedMembers;
});

export { index_get as default };
//# sourceMappingURL=index.get3.mjs.map
