import { c as defineEventHandler, g as getRouterParam, e as getDb, f as createError } from '../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const stats_get = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  const db = await getDb();
  const now = /* @__PURE__ */ new Date();
  const oneYearAgo = /* @__PURE__ */ new Date();
  oneYearAgo.setFullYear(now.getFullYear() - 1);
  const thirtyDaysFromNow = /* @__PURE__ */ new Date();
  thirtyDaysFromNow.setDate(now.getDate() + 30);
  const asd = await db.collection("associations").findOne({ slug });
  if (!asd) throw createError({ statusCode: 404, statusMessage: "ASD non trovata" });
  const members = await db.collection("memberships").find({ association_id: asd._id }).toArray();
  const events = await db.collection("events").find({ association_id: asd._id }).toArray();
  return {
    members: {
      // Un utente è "attivo" se la scadenza è oltre i prossimi 30 giorni
      active: members.filter((m) => new Date(m.expiry_date) > thirtyDaysFromNow).length,
      // "In scadenza" se scade tra oggi e i prossimi 30 giorni
      expiring: members.filter((m) => {
        const d = new Date(m.expiry_date);
        return d > now && d <= thirtyDaysFromNow;
      }).length,
      // "Scaduti recenti" se scaduti da oggi fino a un anno fa
      expired_recent: members.filter((m) => {
        const d = new Date(m.expiry_date);
        return d <= now && d > oneYearAgo;
      }).length,
      // "Persi" se scaduti da più di un anno
      lost: members.filter((m) => new Date(m.expiry_date) <= oneYearAgo).length
    },
    activities: {
      tournaments: {
        published: events.filter((e) => e.category === "torneo" && e.is_published === true).length,
        draft: events.filter((e) => e.category === "torneo" && e.is_published === false).length
      },
      courses: {
        published: events.filter((e) => e.category === "corso" && e.is_published === true).length,
        draft: events.filter((e) => e.category === "corso" && e.is_published === false).length
      },
      free_play: {
        published: events.filter((e) => e.category === "gioco libero" && e.is_published === true).length,
        draft: events.filter((e) => e.category === "gioco libero" && e.is_published === false).length
      },
      others: {
        published: events.filter((e) => e.category === "altro" && e.is_published === true).length,
        draft: events.filter((e) => e.category === "altro" && e.is_published === false).length
      }
    }
  };
});

export { stats_get as default };
//# sourceMappingURL=stats.get.mjs.map
