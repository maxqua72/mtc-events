import { c as defineEventHandler, r as readBody, e as getDb, f as createError } from '../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const associations1_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { name, slug, theme_color } = body;
  const db = await getDb();
  if (!name || !slug) {
    throw createError({
      statusCode: 400,
      statusMessage: "Nome e Slug sono obbligatori"
    });
  }
  const existingAsd = await db.collection("associations").findOne({ slug });
  if (existingAsd) {
    throw createError({
      statusCode: 409,
      statusMessage: "Questo slug \xE8 gi\xE0 in uso da un'altra associazione"
    });
  }
  const newAsd = {
    name,
    slug: slug.toLowerCase().trim().replace(/\s+/g, "-"),
    // Pulizia dello slug
    theme_color: theme_color || "#3b82f6",
    created_at: /* @__PURE__ */ new Date()
  };
  const result = await db.collection("associations").insertOne(newAsd);
  return {
    success: true,
    message: "Associazione creata con successo",
    asd_id: result.insertedId
  };
});

export { associations1_post as default };
//# sourceMappingURL=associations1.post.mjs.map
