import { c as defineEventHandler, g as getRouterParam, l as libExports, f as createError, e as getDb } from '../../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const _id__delete = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  const id = getRouterParam(event, "id");
  if (!slug || !id || !libExports.ObjectId.isValid(id)) {
    throw createError({ statusCode: 400, statusMessage: "Parametri non validi" });
  }
  const db = await getDb();
  const asd = await db.collection("associations").findOne({ slug });
  if (!asd) throw createError({ statusCode: 404 });
  const file = await db.collection("resources.files").findOne({
    _id: new libExports.ObjectId(id),
    "metadata.association_id": asd._id
  });
  if (!file) {
    throw createError({
      statusCode: 403,
      statusMessage: "Non hai i permessi per eliminare questa risorsa o il file non esiste"
    });
  }
  const bucket = new libExports.GridFSBucket(db, { bucketName: "resources" });
  await bucket.delete(new libExports.ObjectId(id));
  return { success: true };
});

export { _id__delete as default };
//# sourceMappingURL=_id_.delete.mjs.map
