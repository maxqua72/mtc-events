import { c as defineEventHandler, r as readBody, e as getDb, f as createError } from '../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const managers1_post = defineEventHandler(async (event) => {
  const body = await readBody(event);
  const { email, association_id } = body;
  const db = await getDb();
  let user = await db.collection("users").findOne({ email });
  if (!user) {
    const newUser = await db.collection("users").insertOne({
      email,
      name: email.split("@")[0],
      // Nome provvisorio dall'email
      is_admin: false,
      created_at: /* @__PURE__ */ new Date()
    });
    user = { _id: newUser.insertedId, email };
  }
  const existing = await db.collection("managers").findOne({
    user_id: user._id,
    association_id: new Object(association_id)
  });
  if (existing) {
    throw createError({
      statusCode: 409,
      statusMessage: "Questo utente \xE8 gi\xE0 manager di questa associazione"
    });
  }
  await db.collection("managers").insertOne({
    user_id: user._id,
    association_id: new Object(association_id),
    role: "MANAGER",
    assigned_at: /* @__PURE__ */ new Date()
  });
  return { success: true, message: "Manager assegnato correttamente" };
});

export { managers1_post as default };
//# sourceMappingURL=managers1.post.mjs.map
