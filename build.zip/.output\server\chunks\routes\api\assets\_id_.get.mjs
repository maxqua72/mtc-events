import { c as defineEventHandler, g as getRouterParam, l as libExports, f as createError, e as getDb, j as setHeaders, k as sendStream } from '../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const _id__get = defineEventHandler(async (event) => {
  var _a;
  const id = getRouterParam(event, "id");
  if (!id || !libExports.ObjectId.isValid(id)) {
    throw createError({ statusCode: 400, statusMessage: "ID non valido" });
  }
  const db = await getDb();
  const bucket = new libExports.GridFSBucket(db, { bucketName: "resources" });
  const files = await db.collection("resources.files").find({ _id: new libExports.ObjectId(id) }).toArray();
  if (!files.length) throw createError({ statusCode: 404, statusMessage: "File non trovato" });
  const file = files[0];
  setHeaders(event, {
    "Content-Type": ((_a = file.metadata) == null ? void 0 : _a.contentType) || "application/octet-stream",
    "Cache-Control": "public, max-age=31536000, immutable"
    // Cache di 1 anno
  });
  return sendStream(event, bucket.openDownloadStream(new libExports.ObjectId(id)));
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
