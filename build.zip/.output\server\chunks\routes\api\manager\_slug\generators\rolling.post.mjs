import { c as defineEventHandler, e as getDb, g as getRouterParam, h as getQuery, f as createError, o as executeRolling } from '../../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const rolling_post = defineEventHandler(async (event) => {
  var _a;
  const db = await getDb();
  const slug = getRouterParam(event, "slug");
  const query = getQuery(event);
  const categoryFilter = query.category;
  const asd = await db.collection("associations").findOne({ slug });
  if (!asd) throw createError({ statusCode: 404, message: "ASD non trovata" });
  const searchFilter = {
    association_id: asd._id,
    status: "active",
    // Qui applichiamo is_published perché questo è un rolling batch (multiplo)
    is_published: true
  };
  if (categoryFilter && categoryFilter !== "all") {
    searchFilter.category = categoryFilter.toLowerCase();
  }
  const generators = await db.collection("generators").find(searchFilter).toArray();
  let totalCreated = 0;
  for (const gen of generators) {
    const daysToCover = ((_a = gen.recurrence) == null ? void 0 : _a.rolling_days) || 30;
    const targetDate = /* @__PURE__ */ new Date();
    targetDate.setDate(targetDate.getDate() + daysToCover);
    const result = await executeRolling(db, gen, targetDate);
    totalCreated += result.count;
  }
  return {
    success: true,
    message: `Generazione completata. Creati ${totalCreated} nuovi eventi.`
  };
});

export { rolling_post as default };
//# sourceMappingURL=rolling.post.mjs.map
