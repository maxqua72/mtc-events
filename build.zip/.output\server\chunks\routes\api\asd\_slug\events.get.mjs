import { c as defineEventHandler, g as getRouterParam, e as getDb, f as createError } from '../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const events_get = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  const db = await getDb();
  const now = /* @__PURE__ */ new Date();
  const asd = await db.collection("associations").findOne({ slug });
  if (!asd) {
    throw createError({
      statusCode: 404,
      statusMessage: `Associazione ${slug} non trovata`
    });
  }
  const events = await db.collection("events").find({
    association_id: asd._id,
    is_published: true,
    $or: [
      // 1. Eventi futuri: la data di inizio è maggiore o uguale a ora
      { start_date: { $gte: now } },
      // 2. Eventi in corso: ora è tra inizio e fine
      {
        start_date: { $lte: now },
        end_date: { $gte: now }
      }
    ]
  }).sort({ start_date: 1 }).toArray();
  return events;
});

export { events_get as default };
//# sourceMappingURL=events.get.mjs.map
