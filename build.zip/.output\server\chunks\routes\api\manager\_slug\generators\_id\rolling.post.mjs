import { c as defineEventHandler, e as getDb, r as readBody, h as getQuery, l as libExports, f as createError, o as executeRolling } from '../../../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const rolling_post = defineEventHandler(async (event) => {
  var _a;
  const db = await getDb();
  const { slug, id } = event.context.params;
  const body = await readBody(event).catch(() => ({}));
  const query = getQuery(event);
  if (id) {
    const generator = await db.collection("generators").findOne({
      _id: new libExports.ObjectId(id),
      asd_slug: slug
    });
    if (!generator) {
      throw createError({ statusCode: 404, message: "Generatore non trovato" });
    }
    const targetDate = body.target_date ? new Date(body.target_date) : /* @__PURE__ */ new Date();
    const result = await executeRolling(db, generator, targetDate);
    return {
      success: true,
      generated_count: result.count,
      last_date: result.last_date
    };
  }
  const category = query.category;
  const filter = {
    asd_slug: slug,
    status: "active",
    is_published: true
  };
  if (category && category !== "tutti") {
    filter.category = category.toLowerCase();
  }
  const generators = await db.collection("generators").find(filter).toArray();
  let totalGenerated = 0;
  const processedGenerators = [];
  for (const gen of generators) {
    const daysToCover = ((_a = gen.recurrence) == null ? void 0 : _a.rolling_days) || 7;
    const autoTargetDate = /* @__PURE__ */ new Date();
    autoTargetDate.setDate(autoTargetDate.getDate() + daysToCover);
    const result = await executeRolling(db, gen, autoTargetDate);
    if (result.count > 0) {
      totalGenerated += result.count;
      processedGenerators.push({ id: gen._id, count: result.count });
    }
  }
  return {
    success: true,
    total_generated: totalGenerated,
    generators_updated: processedGenerators.length,
    scope: category || "all"
  };
});

export { rolling_post as default };
//# sourceMappingURL=rolling.post.mjs.map
