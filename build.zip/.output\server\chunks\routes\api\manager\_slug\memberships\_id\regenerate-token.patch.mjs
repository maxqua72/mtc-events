import { c as defineEventHandler, g as getRouterParam, e as getDb, f as createError, l as libExports } from '../../../../../../_/nitro.mjs';
import { randomUUID } from 'node:crypto';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'consola';
import 'ipx';
import 'node:path';

const regenerateToken_patch = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  const id = getRouterParam(event, "id");
  const db = await getDb();
  const asd = await db.collection("associations").findOne({ slug });
  if (!asd) {
    throw createError({ statusCode: 404, statusMessage: "ASD non trovata" });
  }
  const newToken = randomUUID();
  const result = await db.collection("memberships").updateOne(
    {
      _id: new libExports.ObjectId(id),
      association_id: asd._id
    },
    {
      $set: {
        join_token: newToken,
        updated_at: /* @__PURE__ */ new Date()
      }
    }
  );
  if (result.matchedCount === 0) {
    throw createError({
      statusCode: 404,
      statusMessage: "Socio non trovato o non appartenente a questa associazione"
    });
  }
  return {
    success: true,
    new_token: newToken
  };
});

export { regenerateToken_patch as default };
//# sourceMappingURL=regenerate-token.patch.mjs.map
