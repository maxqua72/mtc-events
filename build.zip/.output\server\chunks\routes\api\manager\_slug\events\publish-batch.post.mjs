import { c as defineEventHandler, e as getDb, r as readBody, g as getRouterParam, f as createError, l as libExports } from '../../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const publishBatch_post = defineEventHandler(async (event) => {
  const db = await getDb();
  const body = await readBody(event);
  const slug = getRouterParam(event, "slug");
  const { eventIds } = body;
  if (!eventIds || !Array.isArray(eventIds) || eventIds.length === 0) {
    throw createError({ statusCode: 400, message: "Nessun ID evento fornito" });
  }
  const asd = await db.collection("associations").findOne({ slug });
  if (!asd) throw createError({ statusCode: 404, message: "ASD non trovata" });
  const objectIds = eventIds.map((id) => new libExports.ObjectId(id));
  try {
    const result = await db.collection("events").updateMany(
      {
        _id: { $in: objectIds },
        association_id: asd._id
      },
      {
        $set: {
          is_published: true,
          updated_at: /* @__PURE__ */ new Date()
        }
      }
    );
    return {
      success: true,
      modifiedCount: result.modifiedCount,
      message: `Pubblicazione completata: ${result.modifiedCount} eventi aggiornati.`
    };
  } catch (error) {
    throw createError({
      statusCode: 500,
      message: "Errore durante l'aggiornamento massivo degli eventi"
    });
  }
});

export { publishBatch_post as default };
//# sourceMappingURL=publish-batch.post.mjs.map
