import { c as defineEventHandler, e as getDb, h as getQuery, f as createError } from '../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const search_get = defineEventHandler(async (event) => {
  try {
    const db = await getDb();
    const { email } = getQuery(event);
    if (!email) return null;
    const user = await db.collection("users").findOne({
      email: email.toString().toLowerCase().trim()
    });
    return user || null;
  } catch (error) {
    throw createError({
      statusCode: 500,
      statusMessage: "Errore interno del database"
    });
  }
});

export { search_get as default };
//# sourceMappingURL=search.get.mjs.map
