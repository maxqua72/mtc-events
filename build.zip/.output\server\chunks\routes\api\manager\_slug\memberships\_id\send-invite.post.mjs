import { c as defineEventHandler, r as readBody, e as getDb, l as libExports, p as getEmailStats, f as createError, q as getRequestHost, v as processEmailQueue } from '../../../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const sendInvite_post = defineEventHandler(async (event) => {
  const { id, slug } = event.context.params;
  const body = await readBody(event);
  const force_queue = (body == null ? void 0 : body.force_queue) || false;
  const db = await getDb();
  const [membership, asd, stats] = await Promise.all([
    db.collection("memberships").findOne({ _id: new libExports.ObjectId(id) }),
    db.collection("associations").findOne({ slug }),
    getEmailStats(db)
    // Ora restituisce dailySent, dailyLimit, monthlySent, monthlyLimit
  ]);
  if (!membership || !asd) {
    throw createError({ statusCode: 404, message: "Dati non trovati" });
  }
  const isDailyFull = stats.dailySent >= stats.dailyLimit;
  const isMonthlyFull = stats.monthlySent >= stats.monthlyLimit;
  if ((isDailyFull || isMonthlyFull) && !force_queue) {
    return {
      success: false,
      code: "QUOTA_EXCEEDED",
      dailySent: stats.dailySent,
      dailyLimit: stats.dailyLimit,
      monthlySent: stats.monthlySent,
      monthlyLimit: stats.monthlyLimit,
      reason: isMonthlyFull ? "monthly" : "daily"
    };
  }
  const protocol = "https" ;
  const host = getRequestHost(event);
  const joinLink = `${protocol}://${host}/${slug}/join?t=${membership.join_token}`;
  const now = /* @__PURE__ */ new Date();
  let scheduledAt = /* @__PURE__ */ new Date();
  if (isMonthlyFull) {
    scheduledAt = new Date(now.getFullYear(), now.getMonth() + 1, 1, 9, 0, 0);
  } else if (isDailyFull) {
    scheduledAt = /* @__PURE__ */ new Date();
    scheduledAt.setDate(scheduledAt.getDate() + 1);
    scheduledAt.setHours(9, 0, 0, 0);
  }
  const emailData = {
    recipient: membership.email,
    from: `"${asd.name}" <inviti@soci.mtc-events.it>`,
    subject: `Benvenuto in ${asd.name} - Attiva la tua tessera`,
    body_html: `
        <div style="font-family: sans-serif; max-width: 600px; margin: auto; border: 1px solid #eee; padding: 20px;">
          <h2 style="color: #2563eb;">Ciao ${membership.name}!</h2>
          <p>L'associazione <b>${asd.name}</b> ti ha invitato a unirti alla loro community su MTC Events.</p>
          <p>Per completare la tua iscrizione e attivare la tua tessera digitale, clicca sul pulsante qui sotto:</p>
          <div style="text-align: center; margin: 30px 0;">
            <a href="${joinLink}" style="background-color: #2563eb; color: white; padding: 12px 25px; text-decoration: none; border-radius: 6px; font-weight: bold;">
              Attiva la mia Membership
            </a>
          </div>
          <p style="font-size: 12px; color: #666;">Se il pulsante non funziona, copia questo link nel tuo browser: <br>${joinLink}</p>
          ${""}
        </div>
      `,
    asd_slug: slug,
    status: "pending",
    priority: 1,
    created_at: /* @__PURE__ */ new Date(),
    scheduled_at: scheduledAt,
    type: "invite"
  };
  await db.collection("email_queue").insertOne(emailData);
  let queued = isDailyFull || isMonthlyFull;
  if (!queued) {
    await processEmailQueue(db, 1);
  }
  return {
    success: true,
    queued,
    message: queued ? "Email messa in coda" : "Email inviata"
  };
});

export { sendInvite_post as default };
//# sourceMappingURL=send-invite.post.mjs.map
