import { c as defineEventHandler, g as getRouterParam, r as readBody, e as getDb, f as createError, l as libExports } from '../../../../_/nitro.mjs';
import { randomUUID } from 'node:crypto';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'consola';
import 'ipx';
import 'node:path';

const index_post = defineEventHandler(async (event) => {
  var _a;
  const slug = getRouterParam(event, "slug");
  const body = await readBody(event);
  const db = await getDb();
  const asd = await db.collection("associations").findOne({ slug });
  if (!asd) {
    throw createError({ statusCode: 404, statusMessage: "ASD non trovata" });
  }
  const filter = body._id ? { _id: new libExports.ObjectId(body._id) } : { email: body.email.toLowerCase().trim(), association_id: asd._id };
  const finalMemberCode = body.member_code || `TESS-${(/* @__PURE__ */ new Date()).getFullYear()}-${Math.floor(1e3 + Math.random() * 9e3)}`;
  const updateData = {
    name: body.name,
    email: (_a = body.email) == null ? void 0 : _a.toLowerCase().trim(),
    member_code: finalMemberCode,
    start_date: new Date(body.start_date),
    expiry_date: new Date(body.expiry_date),
    status: body.status || "active",
    updated_at: /* @__PURE__ */ new Date()
  };
  const insertData = {
    association_id: asd._id,
    // Generiamo il token univoco per il futuro link di join
    join_token: randomUUID(),
    // Fallback per il codice tessera se non fornito
    fcm_tokens: [],
    created_at: /* @__PURE__ */ new Date()
  };
  const result = await db.collection("memberships").updateOne(
    filter,
    {
      $set: updateData,
      $setOnInsert: insertData
    },
    { upsert: true }
  );
  return {
    success: true,
    id: body._id || result.upsertedId
  };
});

export { index_post as default };
//# sourceMappingURL=index.post3.mjs.map
