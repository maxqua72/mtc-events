import { c as defineEventHandler, g as getRouterParam, e as getDb, l as libExports, f as createError } from '../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const _id__get = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const db = await getDb();
  try {
    const eventData = await db.collection("events").findOne({
      _id: new libExports.ObjectId(id)
    });
    if (!eventData) {
      throw createError({ statusCode: 404, statusMessage: "Event not found" });
    }
    return eventData;
  } catch (e) {
    throw createError({ statusCode: 400, statusMessage: "Invalid Event ID" });
  }
});

export { _id__get as default };
//# sourceMappingURL=_id_.get.mjs.map
