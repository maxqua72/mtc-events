import { c as defineEventHandler, g as getRouterParam, h as getQuery, e as getDb, f as createError } from '../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const join_get = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  const { t: token } = getQuery(event);
  const db = await getDb();
  if (!token) {
    throw createError({
      statusCode: 400,
      statusMessage: "Token mancante"
    });
  }
  const asd = await db.collection("associations").findOne({ slug });
  if (!asd) {
    throw createError({ statusCode: 404, statusMessage: "Associazione non trovata" });
  }
  const membership = await db.collection("memberships").findOne({
    join_token: token,
    association_id: asd._id,
    status: "active"
    // Solo soci attivi possono fare la join
  });
  if (!membership) {
    throw createError({
      statusCode: 403,
      statusMessage: "Link non valido, scaduto o socio non attivo"
    });
  }
  const now = /* @__PURE__ */ new Date();
  if (new Date(membership.expiry_date) < now) {
    throw createError({
      statusCode: 403,
      statusMessage: "Iscrizione scaduta. Contatta il manager."
    });
  }
  return {
    name: membership.name,
    email: membership.email,
    member_code: membership.member_code,
    start_date: membership.start_date,
    expiry_date: membership.expiry_date,
    role: "MEMBER"
    // Identifichiamo l'utente come socio da ora in poi
  };
});

export { join_get as default };
//# sourceMappingURL=join.get.mjs.map
