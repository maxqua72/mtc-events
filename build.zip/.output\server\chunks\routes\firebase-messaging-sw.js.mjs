import { c as defineEventHandler, u as useRuntimeConfig, z as setResponseHeader } from '../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const firebaseMessagingSw_js = defineEventHandler((event) => {
  const config = useRuntimeConfig().public.firebase;
  setResponseHeader(event, "Content-Type", "application/javascript");
  return `
    importScripts('https://www.gstatic.com/firebasejs/10.7.1/firebase-app-compat.js');
    importScripts('https://www.gstatic.com/firebasejs/10.7.1/firebase-messaging-compat.js');

    if (!firebase.apps.length) {
      firebase.initializeApp({
        apiKey: "${config.apiKey}",
        authDomain: "${config.authDomain}",
        projectId: "${config.projectId}",
        messagingSenderId: "${config.messagingSenderId}",
        appId: "${config.appId}"
      });
    }

    const messaging = firebase.messaging();

    messaging.onBackgroundMessage((payload) => {
      const notificationTitle = payload.notification.title;
      const notificationOptions = {
        body: payload.notification.body,
        icon: '/icon.png', // Assicurati di avere un'icona adatta in /public/icon.png
        data: payload.data // Utile per gestire i clic sulla notifica
      };
      self.registration.showNotification(notificationTitle, notificationOptions);
    });
  `;
});

export { firebaseMessagingSw_js as default };
//# sourceMappingURL=firebase-messaging-sw.js.mjs.map
