import { c as defineEventHandler, e as getDb, g as getRouterParam, r as readBody, l as libExports } from '../../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const index_patch = defineEventHandler(async (event) => {
  var _a;
  const db = await getDb();
  const id = getRouterParam(event, "id");
  const body = await readBody(event);
  const { _id, asd_slug, ...updateData } = body;
  if (updateData.start_date) updateData.start_date = new Date(updateData.start_date);
  if (updateData.end_date) updateData.end_date = new Date(updateData.end_date);
  if (updateData.registration_time) updateData.registration_time = new Date(updateData.registration_time);
  if ((_a = updateData.recurrence) == null ? void 0 : _a.last_rolling_date) {
    updateData.recurrence.last_rolling_date = new Date(updateData.recurrence.last_rolling_date);
  }
  if (updateData.association_id && typeof updateData.association_id === "string") {
    updateData.association_id = new libExports.ObjectId(updateData.association_id);
  }
  if (updateData.resource_id && typeof updateData.resource_id === "string") {
    updateData.resource_id = new libExports.ObjectId(updateData.resource_id);
  }
  const result = await db.collection("generators").updateOne(
    { _id: new libExports.ObjectId(id) },
    {
      $set: {
        ...updateData,
        updated_at: /* @__PURE__ */ new Date()
      }
    }
  );
  return { success: result.matchedCount > 0 };
});

export { index_patch as default };
//# sourceMappingURL=index.patch.mjs.map
