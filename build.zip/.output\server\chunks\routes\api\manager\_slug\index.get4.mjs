import { c as defineEventHandler, g as getRouterParam, f as createError, e as getDb } from '../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const index_get = defineEventHandler(async (event) => {
  const slug = getRouterParam(event, "slug");
  if (!slug) throw createError({ statusCode: 400, statusMessage: "Slug mancante" });
  const db = await getDb();
  const asd = await db.collection("associations").findOne({ slug });
  if (!asd) throw createError({ statusCode: 404, statusMessage: "ASD non trovata" });
  const files = await db.collection("resources.files").find({
    "metadata.association_id": asd._id,
    "metadata.is_event_private": { $ne: true }
    // Esclude le immagini caricate da file nell'evento
  }).sort({ uploadDate: -1 }).toArray();
  return files.map((file) => {
    var _a, _b, _c;
    return {
      _id: file._id,
      // Usiamo il nome scelto dal MANAGER, altrimenti il nome originale del file
      name: ((_a = file.metadata) == null ? void 0 : _a.displayName) || file.filename,
      url: `/api/assets/${file._id}`,
      // Determiniamo l'icona da mostrare nel frontend
      type: ((_c = (_b = file.metadata) == null ? void 0 : _b.contentType) == null ? void 0 : _c.includes("pdf")) ? "pdf" : "image",
      // Convertiamo i byte in KB leggibili
      size: (file.length / 1024).toFixed(2) + " KB",
      uploadDate: file.uploadDate
    };
  });
});

export { index_get as default };
//# sourceMappingURL=index.get4.mjs.map
