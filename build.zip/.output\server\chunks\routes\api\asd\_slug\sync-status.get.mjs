import { c as defineEventHandler, g as getRouterParam, e as getDb, i as getHeader } from '../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const syncStatus_get = defineEventHandler(async (event) => {
  var _a;
  const slug = getRouterParam(event, "slug");
  const db = await getDb();
  const email = getHeader(event, "x-user-email");
  const membership = await db.collection("memberships").findOne({
    email: email == null ? void 0 : email.toLowerCase(),
    association_id: (_a = await db.collection("associations").findOne({ slug })) == null ? void 0 : _a._id
  });
  if (!membership || membership.status !== "active") {
    return { active: false };
  }
  return {
    active: true,
    profile: {
      name: membership.name,
      email: membership.email,
      expiry_date: membership.expiry_date,
      role: "MEMBER"
    }
  };
});

export { syncStatus_get as default };
//# sourceMappingURL=sync-status.get.mjs.map
