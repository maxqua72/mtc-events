import { c as defineEventHandler, g as getRouterParam, f as createError, r as readBody, q as getRequestHost, e as getDb, x as fbAdmin, y as fbMessaging } from '../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const sendTestPush_post = defineEventHandler(async (event) => {
  var _a, _b;
  const slug = getRouterParam(event, "slug");
  if (!slug) {
    throw createError({ statusCode: 400, message: "Slug mancante" });
  }
  const body = await readBody(event);
  const { email, title, body: messageBody } = body;
  const protocol = "https" ;
  const host = getRequestHost(event);
  const baseUrl = `${protocol}://${host}`;
  console.log("Base URL determinato:", baseUrl);
  console.log("ASD :", slug);
  const db = await getDb();
  const asd = await db.collection("associations").findOne({ slug });
  if (!asd) {
    throw createError({ statusCode: 404, message: "ASD non trovata" });
  }
  let asdLogo = `${baseUrl}/favicon.ico`;
  if (asd == null ? void 0 : asd.logo_url) {
    asdLogo = asd.logo_url.startsWith("http") ? asd.logo_url : `${baseUrl}${asd.logo_url}`;
  }
  console.log("ASD Logo URL:", asdLogo);
  const membership = await db.collection("memberships").findOne({
    email: email.toLowerCase(),
    association_id: asd._id
  });
  if (!membership || !membership.fcm_tokens || membership.fcm_tokens.length === 0) {
    throw createError({
      statusCode: 404,
      statusMessage: "Nessun token push trovato per questo utente"
    });
  }
  const messages = membership.fcm_tokens.map((token) => ({
    token,
    notification: {
      title: title || "Notifica ASD",
      body: messageBody || "Messaggio di test"
    },
    // CONFIGURAZIONE SPECIFICA PER WEB (Browser)
    webpush: {
      notification: {
        icon: asdLogo,
        // Qui è dove Firebase Admin cerca l'icona per i browser
        badge: asdLogo,
        // L'iconcina nella barra di stato (Android)
        requireInteraction: true
        // Opzionale: la notifica non sparisce finché non clicchi
      },
      fcmOptions: {
        link: `${baseUrl}/${slug}/events`
        // URL dove andare al click (gestito nativamente da FCM)
      }
    },
    // Dati extra utili per la logica dell'app
    data: {
      asd_slug: slug,
      asd_logo: asdLogo,
      // URL assoluto necessario qui per il plugin
      click_action: `/${slug}/events`
    }
  }));
  try {
    console.log("Tipo di fbAdmin:", typeof fbAdmin);
    console.log("Funzioni disponibili:", Object.keys(fbAdmin));
    const response = await fbMessaging.sendEach(messages);
    console.log("Risposta invio FCM:", response);
    if ((_b = (_a = response.responses) == null ? void 0 : _a[0]) == null ? void 0 : _b.error) {
      console.log("Dettaglio Errore FCM:", JSON.stringify(response.responses[0].error, null, 2));
    }
    return {
      success: true,
      sentCount: response.successCount,
      failureCount: response.failureCount
    };
  } catch (error) {
    console.error("Errore invio FCM:", error);
    throw createError({
      statusCode: 500,
      statusMessage: "Errore durante l'invio della notifica"
    });
  }
});

export { sendTestPush_post as default };
//# sourceMappingURL=send-test-push.post.mjs.map
