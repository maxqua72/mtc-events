import { c as defineEventHandler, h as getQuery, e as getDb } from '../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const permissions_get = defineEventHandler(async (event) => {
  const { email } = getQuery(event);
  const db = await getDb();
  const response = {
    email,
    name: "",
    is_admin: false,
    managed_asds: [],
    member_identities: []
  };
  const user = await db.collection("users").findOne({ email });
  if (!user) return response;
  response.is_admin = !!user.is_admin;
  response.name = user.name || "Utente";
  const managerRoles = await db.collection("managers").aggregate([
    { $match: { user_id: user._id } },
    { $lookup: {
      from: "associations",
      localField: "association_id",
      foreignField: "_id",
      as: "asd"
    } },
    { $unwind: "$asd" },
    { $project: { role: 1, asd_slug: "$asd.slug", asd_name: "$asd.name" } }
  ]).toArray();
  response.managed_asds = managerRoles;
  const memberships = await db.collection("memberships").aggregate([
    { $match: { email, status: "active" } },
    { $lookup: {
      from: "associations",
      localField: "association_id",
      foreignField: "_id",
      as: "asd"
    } },
    { $unwind: "$asd" },
    { $project: {
      asd_slug: "$asd.slug",
      name: 1,
      email: 1,
      expiry_date: 1,
      start_date: 1,
      member_code: 1
    } }
  ]).toArray();
  response.member_identities = memberships;
  return response;
});

export { permissions_get as default };
//# sourceMappingURL=permissions.get.mjs.map
