import { c as defineEventHandler, g as getRouterParam, e as getDb, r as readBody, l as libExports, f as createError } from '../../../../_/nitro.mjs';
import 'postal-mime';
import 'svix';
import 'google-auth-library';
import 'node-forge';
import 'fast-deep-equal';
import 'https';
import 'http2';
import '@fastify/busboy';
import 'jsonwebtoken';
import 'jwks-rsa';
import '@firebase/database-compat/standalone';
import 'object-hash';
import 'protobufjs';
import 'crypto';
import 'querystring';
import 'proto3-json-serializer';
import 'duplexify';
import 'retry-request';
import 'protobufjs/minimal';
import 'abort-controller';
import 'assert';
import 'functional-red-black-tree';
import '@grpc/grpc-js';
import '@grpc/proto-loader';
import 'path';
import 'timers';
import 'fs';
import 'http';
import 'process';
import 'stream';
import 'events';
import 'util';
import 'timers/promises';
import 'dns';
import 'os';
import 'url';
import 'zlib';
import 'net';
import 'fs/promises';
import 'tls';
import 'child_process';
import 'sparse-bitfield';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:url';
import 'node:crypto';
import 'consola';
import 'ipx';
import 'node:path';

const _id__put = defineEventHandler(async (event) => {
  const id = getRouterParam(event, "id");
  const db = await getDb();
  const body = await readBody(event);
  if (!id || !libExports.ObjectId.isValid(id)) {
    throw createError({ statusCode: 400, statusMessage: "ID ASD non valido" });
  }
  const { _id, ...updateData } = body;
  updateData.updated_at = /* @__PURE__ */ new Date();
  const result = await db.collection("associations").updateOne(
    { _id: new libExports.ObjectId(id) },
    { $set: updateData }
  );
  if (result.matchedCount === 0) {
    throw createError({ statusCode: 404, statusMessage: "ASD non trovata" });
  }
  return { success: true };
});

export { _id__put as default };
//# sourceMappingURL=_id_.put.mjs.map
